// ============================================
// AUTHENTICATION MODULE
// Google OAuth Integration & User Management
// ============================================

// Global auth state
let currentUser = null;
let isAdmin = false;

// Anonymous name generator
const ADJECTIVES = [
    'Gizemli', 'Sessiz', 'Hızlı', 'Cesur', 'Akıllı', 'Güçlü', 'Parlak', 'Soğuk',
    'Sıcak', 'Yumuşak', 'Sert', 'Nazik', 'Vahşi', 'Sakin', 'Çılgın', 'Mavi',
    'Kırmızı', 'Yeşil', 'Altın', 'Gümüş', 'Gölge', 'Işık', 'Kahraman', 'Ninja'
];

const NOUNS = [
    'Kaplan', 'Aslan', 'Kartal', 'Kurt', 'Panter', 'Ejderha', 'Yıldız', 'Ay',
    'Güneş', 'Fırtına', 'Şimşek', 'Gök', 'Deniz', 'Dağ', 'Ateş', 'Buz',
    'Rüzgar', 'Toprak', 'Su', 'Ağaç', 'Taş', 'Kılıç', 'Kalkan', 'Zırh'
];

const COLORS = [
    '#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A', '#98D8C8', '#F7DC6F',
    '#BB8FCE', '#85C1E2', '#F8B739', '#52B788', '#E76F51', '#2A9D8F',
    '#E63946', '#F77F00', '#06D6A0', '#118AB2', '#073B4C', '#FFD166'
];

// Generate anonymous name
function generateAnonymousName() {
    const adj = ADJECTIVES[Math.floor(Math.random() * ADJECTIVES.length)];
    const noun = NOUNS[Math.floor(Math.random() * NOUNS.length)];
    const num = Math.floor(Math.random() * 999) + 1;
    return `${adj}${noun}${num}`;
}

// Generate random color
function generateColor() {
    return COLORS[Math.floor(Math.random() * COLORS.length)];
}

// Initialize Google Sign-In
function initializeGoogleSignIn() {
    // Note: You need to replace 'YOUR_GOOGLE_CLIENT_ID' with your actual Google OAuth Client ID
    // Get it from: https://console.cloud.google.com/
    
    google.accounts.id.initialize({
        client_id: 'YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com',
        callback: handleGoogleSignIn,
        auto_select: false
    });

    google.accounts.id.renderButton(
        document.getElementById('googleSignInButton'),
        {
            theme: 'filled_blue',
            size: 'large',
            text: 'signin_with',
            shape: 'rectangular',
            logo_alignment: 'left',
            locale: 'tr'
        }
    );

    // Check if user is already logged in (from localStorage)
    checkExistingSession();
}

// Handle Google Sign-In response
async function handleGoogleSignIn(response) {
    try {
        // Decode JWT token to get user info
        const userInfo = parseJwt(response.credential);
        
        console.log('Google Sign-In Success:', userInfo);
        
        // Check if user exists in database
        const existingUser = await checkUserExists(userInfo.sub);
        
        if (existingUser) {
            // User exists, load their data
            currentUser = existingUser;
        } else {
            // Create new user
            currentUser = await createNewUser(userInfo);
        }
        
        // Save session
        saveSession(currentUser);
        
        // Update UI
        updateAuthUI(true);
        
        // Show success message
        showNotification('Başarıyla giriş yaptınız!', 'success');
        
        // Load forum data
        if (typeof loadForumData === 'function') {
            loadForumData();
        }
        
    } catch (error) {
        console.error('Sign-in error:', error);
        showNotification('Giriş yapılırken bir hata oluştu.', 'error');
    }
}

// Parse JWT token
function parseJwt(token) {
    try {
        const base64Url = token.split('.')[1];
        const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        const jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''));
        return JSON.parse(jsonPayload);
    } catch (error) {
        console.error('JWT parse error:', error);
        return null;
    }
}

// Check if user exists in database
async function checkUserExists(googleId) {
    try {
        const response = await fetch(`tables/users?search=${googleId}`);
        const data = await response.json();
        
        if (data.data && data.data.length > 0) {
            // Find user with matching google_id
            const user = data.data.find(u => u.google_id === googleId);
            return user || null;
        }
        return null;
    } catch (error) {
        console.error('Error checking user:', error);
        return null;
    }
}

// Create new user
async function createNewUser(googleInfo) {
    try {
        const userData = {
            google_id: googleInfo.sub,
            email: googleInfo.email,
            real_name: googleInfo.name,
            anonymous_name: generateAnonymousName(),
            avatar_color: generateColor(),
            is_admin: false,
            joined_at: new Date().toISOString()
        };
        
        const response = await fetch('tables/users', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(userData)
        });
        
        if (!response.ok) {
            throw new Error('Failed to create user');
        }
        
        const newUser = await response.json();
        console.log('New user created:', newUser);
        
        return newUser;
    } catch (error) {
        console.error('Error creating user:', error);
        throw error;
    }
}

// Save session to localStorage
function saveSession(user) {
    localStorage.setItem('currentUser', JSON.stringify(user));
    localStorage.setItem('sessionExpiry', Date.now() + (7 * 24 * 60 * 60 * 1000)); // 7 days
}

// Check existing session
async function checkExistingSession() {
    const savedUser = localStorage.getItem('currentUser');
    const expiry = localStorage.getItem('sessionExpiry');
    
    if (savedUser && expiry && Date.now() < parseInt(expiry)) {
        currentUser = JSON.parse(savedUser);
        
        // Verify user still exists in database
        const existingUser = await checkUserExists(currentUser.google_id);
        
        if (existingUser) {
            currentUser = existingUser;
            saveSession(currentUser);
            updateAuthUI(true);
            
            if (typeof loadForumData === 'function') {
                loadForumData();
            }
        } else {
            logout();
        }
    }
}

// Update authentication UI
function updateAuthUI(isLoggedIn) {
    const googleSignInButton = document.getElementById('googleSignInButton');
    const userInfo = document.getElementById('userInfo');
    const userName = document.getElementById('userName');
    const userAvatar = document.getElementById('userAvatar');
    const welcomeBanner = document.getElementById('welcomeBanner');
    const createPostSection = document.getElementById('createPostSection');
    
    if (isLoggedIn && currentUser) {
        // Hide sign-in button
        googleSignInButton.style.display = 'none';
        
        // Show user info
        userInfo.style.display = 'flex';
        userName.textContent = currentUser.anonymous_name;
        userAvatar.style.backgroundColor = currentUser.avatar_color;
        userAvatar.textContent = currentUser.anonymous_name.charAt(0);
        
        // Hide welcome banner
        if (welcomeBanner) {
            welcomeBanner.style.display = 'none';
        }
        
        // Show create post section
        if (createPostSection) {
            createPostSection.style.display = 'block';
        }
        
        // Check if admin
        isAdmin = currentUser.is_admin || false;
        
        // Show admin menu if admin
        const adminLinks = document.querySelectorAll('.admin-only');
        adminLinks.forEach(link => {
            link.style.display = isAdmin ? 'flex' : 'none';
        });
        
    } else {
        // Show sign-in button
        googleSignInButton.style.display = 'block';
        
        // Hide user info
        userInfo.style.display = 'none';
        
        // Show welcome banner
        if (welcomeBanner) {
            welcomeBanner.style.display = 'block';
        }
        
        // Hide create post section
        if (createPostSection) {
            createPostSection.style.display = 'none';
        }
        
        // Hide admin menu
        const adminLinks = document.querySelectorAll('.admin-only');
        adminLinks.forEach(link => {
            link.style.display = 'none';
        });
    }
}

// Logout
function logout() {
    currentUser = null;
    isAdmin = false;
    localStorage.removeItem('currentUser');
    localStorage.removeItem('sessionExpiry');
    updateAuthUI(false);
    showNotification('Başarıyla çıkış yaptınız.', 'info');
    
    // Reload page
    setTimeout(() => {
        window.location.reload();
    }, 1000);
}

// Show notification
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6'};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 0.5rem;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.4);
        z-index: 9999;
        animation: slideIn 0.3s ease-out;
        max-width: 300px;
    `;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease-out';
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 3000);
}

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Initialize auth when DOM is loaded
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeGoogleSignIn);
} else {
    initializeGoogleSignIn();
}

// Setup logout button
document.addEventListener('DOMContentLoaded', () => {
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', logout);
    }
});
