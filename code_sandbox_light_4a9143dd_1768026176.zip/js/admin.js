// ============================================
// ADMIN MODULE
// Admin panel with real user identities visible
// ============================================

let currentAdminTab = 'users';

// Load admin panel
async function loadAdminPanel() {
    if (!isAdmin) {
        showNotification('Bu sayfaya erişim yetkiniz yok', 'error');
        switchPage('forum');
        return;
    }
    
    await loadAdminTab(currentAdminTab);
}

// Load admin tab
async function loadAdminTab(tabName) {
    const adminContent = document.getElementById('adminContent');
    if (!adminContent) return;
    
    currentAdminTab = tabName;
    
    // Update tab buttons
    document.querySelectorAll('.admin-tab').forEach(tab => {
        tab.classList.remove('active');
        if (tab.getAttribute('data-tab') === tabName) {
            tab.classList.add('active');
        }
    });
    
    adminContent.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i> Yükleniyor...</div>';
    
    try {
        switch (tabName) {
            case 'users':
                await loadUsersTab();
                break;
            case 'posts':
                await loadPostsTab();
                break;
            case 'stats':
                await loadStatsTab();
                break;
        }
    } catch (error) {
        console.error('Error loading admin tab:', error);
        adminContent.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-exclamation-triangle"></i>
                <h3>Bir hata oluştu</h3>
                <p>Veri yüklenemedi.</p>
            </div>
        `;
    }
}

// Load users tab - REAL identities visible
async function loadUsersTab() {
    const adminContent = document.getElementById('adminContent');
    
    try {
        const response = await fetch('tables/users?limit=1000');
        const data = await response.json();
        const users = data.data || [];
        
        let html = `
            <div style="margin-bottom: 1rem;">
                <h2 style="color: var(--text-primary); margin-bottom: 0.5rem;">
                    <i class="fas fa-users"></i> Kullanıcılar (${users.length})
                </h2>
                <p style="color: var(--warning-color); display: flex; align-items: center; gap: 0.5rem;">
                    <i class="fas fa-exclamation-triangle"></i>
                    Bu panel sadece admin tarafından görülebilir. Gerçek kimlikler burada gösterilir.
                </p>
            </div>
            <div style="overflow-x: auto;">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Anonim İsim</th>
                            <th>Gerçek İsim</th>
                            <th>Email</th>
                            <th>Google ID</th>
                            <th>Kayıt Tarihi</th>
                            <th>Admin</th>
                            <th>İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
        `;
        
        users.forEach(user => {
            html += `
                <tr>
                    <td>
                        <div style="display: flex; align-items: center; gap: 0.5rem;">
                            <div style="width: 32px; height: 32px; border-radius: 50%; background: ${user.avatar_color}; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">
                                ${user.anonymous_name.charAt(0)}
                            </div>
                            <span style="font-weight: 600;">${user.anonymous_name}</span>
                        </div>
                    </td>
                    <td style="color: var(--primary-light); font-weight: 600;">${user.real_name}</td>
                    <td style="color: var(--text-secondary);">${user.email}</td>
                    <td style="color: var(--text-muted); font-size: 0.85rem;">${user.google_id.substring(0, 20)}...</td>
                    <td>${formatDate(user.joined_at)}</td>
                    <td>
                        ${user.is_admin ? 
                            '<span style="color: var(--success-color);"><i class="fas fa-check-circle"></i> Evet</span>' : 
                            '<span style="color: var(--text-muted);"><i class="fas fa-times-circle"></i> Hayır</span>'
                        }
                    </td>
                    <td>
                        <button 
                            onclick="toggleAdminStatus('${user.id}', ${!user.is_admin})" 
                            class="btn-sm"
                            style="padding: 0.25rem 0.75rem; background: ${user.is_admin ? 'var(--danger-color)' : 'var(--success-color)'}; color: white; border: none; border-radius: 0.25rem; cursor: pointer; font-size: 0.85rem;"
                        >
                            ${user.is_admin ? '<i class="fas fa-user-minus"></i> Admin Kaldır' : '<i class="fas fa-user-plus"></i> Admin Yap'}
                        </button>
                    </td>
                </tr>
            `;
        });
        
        html += `
                    </tbody>
                </table>
            </div>
        `;
        
        adminContent.innerHTML = html;
        
    } catch (error) {
        throw error;
    }
}

// Load posts tab
async function loadPostsTab() {
    const adminContent = document.getElementById('adminContent');
    
    try {
        const postsResponse = await fetch('tables/posts?limit=1000&sort=-created_at');
        const postsData = await postsResponse.json();
        const posts = postsData.data || [];
        
        const usersResponse = await fetch('tables/users?limit=1000');
        const usersData = await usersResponse.json();
        const users = usersData.data || [];
        
        const userMap = {};
        users.forEach(user => {
            userMap[user.id] = user;
        });
        
        // Filter main posts (not replies)
        const mainPosts = posts.filter(post => !post.reply_to);
        
        let html = `
            <div style="margin-bottom: 1rem;">
                <h2 style="color: var(--text-primary); margin-bottom: 0.5rem;">
                    <i class="fas fa-comments"></i> Gönderiler (${mainPosts.length})
                </h2>
                <p style="color: var(--text-secondary);">
                    Tüm forum gönderileri ve yazarların gerçek kimlikleri
                </p>
            </div>
            <div style="overflow-x: auto;">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Başlık</th>
                            <th>Yazar (Anonim)</th>
                            <th>Yazar (Gerçek)</th>
                            <th>Kategori</th>
                            <th>Beğeni</th>
                            <th>Yanıt</th>
                            <th>Tarih</th>
                            <th>İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
        `;
        
        mainPosts.forEach(post => {
            const author = userMap[post.user_id];
            const authorAnonymous = author ? author.anonymous_name : 'Bilinmeyen';
            const authorReal = author ? author.real_name : 'Bilinmeyen';
            const replyCount = posts.filter(p => p.reply_to === post.id).length;
            
            html += `
                <tr>
                    <td style="max-width: 300px;">
                        <div style="font-weight: 600; color: var(--text-primary); margin-bottom: 0.25rem;">
                            ${escapeHtml(post.title)}
                        </div>
                        <div style="color: var(--text-muted); font-size: 0.85rem;">
                            ${truncateText(escapeHtml(post.content), 80)}
                        </div>
                    </td>
                    <td>${authorAnonymous}</td>
                    <td style="color: var(--primary-light); font-weight: 600;">${authorReal}</td>
                    <td>
                        <span style="background: var(--primary-color); color: white; padding: 0.25rem 0.5rem; border-radius: 0.25rem; font-size: 0.85rem;">
                            ${post.category}
                        </span>
                    </td>
                    <td style="text-align: center;">
                        <i class="fas fa-heart" style="color: var(--danger-color);"></i> ${post.likes || 0}
                    </td>
                    <td style="text-align: center;">
                        <i class="fas fa-comment"></i> ${replyCount}
                    </td>
                    <td>${formatDate(post.created_at)}</td>
                    <td>
                        <button 
                            onclick="deletePost('${post.id}')" 
                            class="btn-sm"
                            style="padding: 0.25rem 0.75rem; background: var(--danger-color); color: white; border: none; border-radius: 0.25rem; cursor: pointer; font-size: 0.85rem;"
                        >
                            <i class="fas fa-trash"></i> Sil
                        </button>
                    </td>
                </tr>
            `;
        });
        
        html += `
                    </tbody>
                </table>
            </div>
        `;
        
        adminContent.innerHTML = html;
        
    } catch (error) {
        throw error;
    }
}

// Load stats tab
async function loadStatsTab() {
    const adminContent = document.getElementById('adminContent');
    
    try {
        const usersResponse = await fetch('tables/users?limit=1000');
        const usersData = await usersResponse.json();
        const users = usersData.data || [];
        
        const postsResponse = await fetch('tables/posts?limit=1000');
        const postsData = await postsResponse.json();
        const posts = postsData.data || [];
        
        const categoriesResponse = await fetch('tables/categories?limit=100');
        const categoriesData = await categoriesResponse.json();
        const categories = categoriesData.data || [];
        
        // Calculate stats
        const totalUsers = users.length;
        const totalPosts = posts.filter(p => !p.reply_to).length;
        const totalReplies = posts.filter(p => p.reply_to).length;
        const totalLikes = posts.reduce((sum, post) => sum + (post.likes || 0), 0);
        const totalAdmins = users.filter(u => u.is_admin).length;
        
        // Category stats
        let categoryStats = '';
        categories.forEach(cat => {
            const count = posts.filter(p => p.category === cat.name && !p.reply_to).length;
            categoryStats += `
                <div style="background: var(--bg-tertiary); padding: 1rem; border-radius: 0.5rem; border: 1px solid var(--border-color);">
                    <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
                        <i class="fas ${cat.icon}" style="font-size: 1.5rem; color: var(--primary-color);"></i>
                        <span style="font-weight: 600; color: var(--text-primary);">${cat.name}</span>
                    </div>
                    <div style="font-size: 2rem; font-weight: 700; color: var(--primary-light);">
                        ${count}
                    </div>
                    <div style="color: var(--text-muted); font-size: 0.85rem;">gönderi</div>
                </div>
            `;
        });
        
        // Most active users
        const userPostCounts = {};
        posts.forEach(post => {
            if (post.user_id) {
                userPostCounts[post.user_id] = (userPostCounts[post.user_id] || 0) + 1;
            }
        });
        
        const topUsers = Object.entries(userPostCounts)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5);
        
        let topUsersHtml = '';
        topUsers.forEach(([userId, count]) => {
            const user = users.find(u => u.id === userId);
            if (user) {
                topUsersHtml += `
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 0.75rem; background: var(--bg-tertiary); border-radius: 0.5rem; margin-bottom: 0.5rem;">
                        <div style="display: flex; align-items: center; gap: 0.5rem;">
                            <div style="width: 32px; height: 32px; border-radius: 50%; background: ${user.avatar_color}; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">
                                ${user.anonymous_name.charAt(0)}
                            </div>
                            <div>
                                <div style="font-weight: 600; color: var(--text-primary);">${user.anonymous_name}</div>
                                <div style="font-size: 0.85rem; color: var(--primary-light);">${user.real_name}</div>
                            </div>
                        </div>
                        <div style="font-weight: 700; color: var(--primary-color); font-size: 1.2rem;">
                            ${count}
                        </div>
                    </div>
                `;
            }
        });
        
        let html = `
            <div style="margin-bottom: 1rem;">
                <h2 style="color: var(--text-primary); margin-bottom: 0.5rem;">
                    <i class="fas fa-chart-bar"></i> İstatistikler
                </h2>
                <p style="color: var(--text-secondary);">Forum kullanım istatistikleri</p>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 2rem;">
                <div style="background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%); padding: 1.5rem; border-radius: 0.75rem; color: white;">
                    <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
                        <i class="fas fa-users" style="font-size: 1.5rem;"></i>
                        <span style="font-weight: 600;">Toplam Kullanıcı</span>
                    </div>
                    <div style="font-size: 2.5rem; font-weight: 700;">${totalUsers}</div>
                </div>
                
                <div style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); padding: 1.5rem; border-radius: 0.75rem; color: white;">
                    <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
                        <i class="fas fa-comments" style="font-size: 1.5rem;"></i>
                        <span style="font-weight: 600;">Toplam Gönderi</span>
                    </div>
                    <div style="font-size: 2.5rem; font-weight: 700;">${totalPosts}</div>
                </div>
                
                <div style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); padding: 1.5rem; border-radius: 0.75rem; color: white;">
                    <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
                        <i class="fas fa-comment" style="font-size: 1.5rem;"></i>
                        <span style="font-weight: 600;">Toplam Yanıt</span>
                    </div>
                    <div style="font-size: 2.5rem; font-weight: 700;">${totalReplies}</div>
                </div>
                
                <div style="background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); padding: 1.5rem; border-radius: 0.75rem; color: white;">
                    <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
                        <i class="fas fa-heart" style="font-size: 1.5rem;"></i>
                        <span style="font-weight: 600;">Toplam Beğeni</span>
                    </div>
                    <div style="font-size: 2.5rem; font-weight: 700;">${totalLikes}</div>
                </div>
                
                <div style="background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%); padding: 1.5rem; border-radius: 0.75rem; color: white;">
                    <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
                        <i class="fas fa-shield-alt" style="font-size: 1.5rem;"></i>
                        <span style="font-weight: 600;">Admin Sayısı</span>
                    </div>
                    <div style="font-size: 2.5rem; font-weight: 700;">${totalAdmins}</div>
                </div>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem;">
                <div>
                    <h3 style="color: var(--text-primary); margin-bottom: 1rem;">
                        <i class="fas fa-th-large"></i> Kategorilere Göre Gönderiler
                    </h3>
                    <div style="display: grid; gap: 1rem;">
                        ${categoryStats}
                    </div>
                </div>
                
                <div>
                    <h3 style="color: var(--text-primary); margin-bottom: 1rem;">
                        <i class="fas fa-trophy"></i> En Aktif Kullanıcılar
                    </h3>
                    <div>
                        ${topUsersHtml || '<p style="color: var(--text-muted); text-align: center;">Henüz veri yok</p>'}
                    </div>
                </div>
            </div>
        `;
        
        adminContent.innerHTML = html;
        
    } catch (error) {
        throw error;
    }
}

// Toggle admin status
async function toggleAdminStatus(userId, makeAdmin) {
    if (!confirm(`Bu kullanıcıyı ${makeAdmin ? 'admin yapmak' : 'adminlikten çıkarmak'} istediğinize emin misiniz?`)) {
        return;
    }
    
    try {
        const response = await fetch(`tables/users/${userId}`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ is_admin: makeAdmin })
        });
        
        if (response.ok) {
            showNotification(`Kullanıcı ${makeAdmin ? 'admin yapıldı' : 'adminlikten çıkarıldı'}`, 'success');
            await loadUsersTab();
        }
    } catch (error) {
        console.error('Error toggling admin status:', error);
        showNotification('İşlem başarısız oldu', 'error');
    }
}

// Delete post
async function deletePost(postId) {
    if (!confirm('Bu gönderiyi silmek istediğinize emin misiniz? Bu işlem geri alınamaz.')) {
        return;
    }
    
    try {
        const response = await fetch(`tables/posts/${postId}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            showNotification('Gönderi silindi', 'success');
            
            // Remove from allPosts array
            const index = allPosts.findIndex(p => p.id === postId);
            if (index > -1) {
                allPosts.splice(index, 1);
            }
            
            await loadPostsTab();
        }
    } catch (error) {
        console.error('Error deleting post:', error);
        showNotification('Gönderi silinemedi', 'error');
    }
}

// Setup admin tab buttons
document.addEventListener('DOMContentLoaded', () => {
    const adminTabs = document.querySelectorAll('.admin-tab');
    
    adminTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const tabName = tab.getAttribute('data-tab');
            loadAdminTab(tabName);
        });
    });
});
