// ============================================
// MAIN MODULE
// Page navigation and app initialization
// ============================================

// Switch between pages
function switchPage(pageName) {
    // Hide all pages
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    
    // Show selected page
    const selectedPage = document.getElementById(`${pageName}Page`);
    if (selectedPage) {
        selectedPage.classList.add('active');
    }
    
    // Update navigation
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('data-page') === pageName) {
            link.classList.add('active');
        }
    });
    
    // Load page-specific data
    switch (pageName) {
        case 'forum':
            if (currentUser) {
                loadForumData();
            }
            break;
        case 'categories':
            loadCategories();
            break;
        case 'admin':
            if (isAdmin) {
                loadAdminPanel();
            } else {
                showNotification('Bu sayfaya erişim yetkiniz yok', 'error');
                switchPage('forum');
            }
            break;
    }
}

// Setup navigation
document.addEventListener('DOMContentLoaded', () => {
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const page = link.getAttribute('data-page');
            switchPage(page);
        });
    });
    
    // Initialize with forum page
    switchPage('forum');
});

// Initialize app
async function initializeApp() {
    try {
        // Load categories first (they don't require auth)
        await loadCategories();
        
        // If user is logged in, load forum data
        if (currentUser) {
            await loadForumData();
        }
        
        console.log('App initialized successfully');
    } catch (error) {
        console.error('Error initializing app:', error);
    }
}

// Call initialization after a short delay to ensure auth is loaded
setTimeout(initializeApp, 500);

// Handle browser back/forward buttons
window.addEventListener('popstate', () => {
    // You can implement URL-based routing here if needed
});

// Prevent form submission on Enter key (except in textareas)
document.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') {
        const form = e.target.closest('form');
        if (form) {
            e.preventDefault();
        }
    }
});

// Add smooth scrolling
document.addEventListener('click', (e) => {
    if (e.target.matches('a[href^="#"]')) {
        e.preventDefault();
        const target = document.querySelector(e.target.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    }
});

// Add loading indicator for fetch requests
let activeRequests = 0;

const originalFetch = window.fetch;
window.fetch = function(...args) {
    activeRequests++;
    updateLoadingIndicator();
    
    return originalFetch.apply(this, args)
        .finally(() => {
            activeRequests--;
            updateLoadingIndicator();
        });
};

function updateLoadingIndicator() {
    // You can add a global loading indicator here if desired
    // For example, show a loading bar at the top of the page
}

// Error handling for unhandled promise rejections
window.addEventListener('unhandledrejection', (event) => {
    console.error('Unhandled promise rejection:', event.reason);
    showNotification('Beklenmeyen bir hata oluştu', 'error');
});

// Service worker registration (for PWA support - optional)
if ('serviceWorker' in navigator) {
    // Uncomment below to enable service worker
    // navigator.serviceWorker.register('/sw.js')
    //     .then(registration => {
    //         console.log('Service Worker registered:', registration);
    //     })
    //     .catch(error => {
    //         console.log('Service Worker registration failed:', error);
    //     });
}

// Add meta theme color based on scroll position
let lastScrollTop = 0;
window.addEventListener('scroll', () => {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    
    // Add shadow to header when scrolled
    const header = document.querySelector('.header');
    if (header) {
        if (scrollTop > 10) {
            header.style.boxShadow = '0 4px 6px -1px rgba(0, 0, 0, 0.3)';
        } else {
            header.style.boxShadow = '';
        }
    }
    
    lastScrollTop = scrollTop;
});

// Auto-save draft posts (optional feature)
let draftSaveTimer;
document.addEventListener('DOMContentLoaded', () => {
    const postTitle = document.getElementById('postTitle');
    const postContent = document.getElementById('postContent');
    const postCategory = document.getElementById('postCategory');
    
    if (postTitle && postContent && postCategory) {
        // Load saved draft
        const savedDraft = localStorage.getItem('postDraft');
        if (savedDraft) {
            try {
                const draft = JSON.parse(savedDraft);
                postTitle.value = draft.title || '';
                postContent.value = draft.content || '';
                postCategory.value = draft.category || '';
            } catch (e) {
                console.error('Error loading draft:', e);
            }
        }
        
        // Auto-save draft on input
        const saveDraft = () => {
            clearTimeout(draftSaveTimer);
            draftSaveTimer = setTimeout(() => {
                const draft = {
                    title: postTitle.value,
                    content: postContent.value,
                    category: postCategory.value
                };
                localStorage.setItem('postDraft', JSON.stringify(draft));
            }, 1000);
        };
        
        postTitle.addEventListener('input', saveDraft);
        postContent.addEventListener('input', saveDraft);
        postCategory.addEventListener('change', saveDraft);
        
        // Clear draft on successful submission
        const createPostForm = document.getElementById('createPostForm');
        if (createPostForm) {
            createPostForm.addEventListener('submit', () => {
                // Clear draft after a short delay (to allow form submission to complete)
                setTimeout(() => {
                    localStorage.removeItem('postDraft');
                }, 2000);
            });
        }
    }
});

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    // Ctrl/Cmd + K: Focus search (if implemented)
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        // Implement search focus here
    }
    
    // Escape: Close modal
    if (e.key === 'Escape') {
        const modal = document.getElementById('postModal');
        if (modal && modal.classList.contains('active')) {
            modal.classList.remove('active');
        }
    }
});

// Add copy-to-clipboard functionality for share links
function copyToClipboard(text) {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text)
            .then(() => {
                showNotification('Link kopyalandı!', 'success');
            })
            .catch(err => {
                console.error('Failed to copy:', err);
                fallbackCopyToClipboard(text);
            });
    } else {
        fallbackCopyToClipboard(text);
    }
}

function fallbackCopyToClipboard(text) {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    
    try {
        document.execCommand('copy');
        showNotification('Link kopyalandı!', 'success');
    } catch (err) {
        console.error('Fallback copy failed:', err);
        showNotification('Kopyalama başarısız oldu', 'error');
    }
    
    document.body.removeChild(textArea);
}

// Add PWA install prompt
let deferredPrompt;

window.addEventListener('beforeinstallprompt', (e) => {
    // Prevent the mini-infobar from appearing on mobile
    e.preventDefault();
    // Stash the event so it can be triggered later
    deferredPrompt = e;
    
    // Show install button if desired
    // const installBtn = document.getElementById('installBtn');
    // if (installBtn) {
    //     installBtn.style.display = 'block';
    // }
});

// Function to trigger install prompt
function installApp() {
    if (deferredPrompt) {
        deferredPrompt.prompt();
        deferredPrompt.userChoice.then((choiceResult) => {
            if (choiceResult.outcome === 'accepted') {
                console.log('User accepted the install prompt');
                showNotification('Uygulama yükleniyor...', 'success');
            } else {
                console.log('User dismissed the install prompt');
            }
            deferredPrompt = null;
        });
    }
}

// Add online/offline detection
window.addEventListener('online', () => {
    showNotification('İnternet bağlantısı yeniden kuruldu', 'success');
});

window.addEventListener('offline', () => {
    showNotification('İnternet bağlantısı kesildi', 'warning');
});

// Add visibility change detection (for pausing/resuming activities)
document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        // Page is hidden - pause activities if needed
        console.log('Page hidden');
    } else {
        // Page is visible - resume activities
        console.log('Page visible');
        // Optionally refresh data
        if (currentUser && window.location.hash === '#forum') {
            // loadForumData();
        }
    }
});

// Add performance monitoring (optional)
if (window.performance && window.performance.timing) {
    window.addEventListener('load', () => {
        setTimeout(() => {
            const perfData = window.performance.timing;
            const pageLoadTime = perfData.loadEventEnd - perfData.navigationStart;
            console.log(`Page load time: ${pageLoadTime}ms`);
        }, 0);
    });
}

// Export functions for use in other modules
window.switchPage = switchPage;
window.copyToClipboard = copyToClipboard;
window.installApp = installApp;

console.log('Main module loaded successfully');
