// ============================================
// FORUM MODULE
// Post management, display, and interactions
// ============================================

let allPosts = [];
let allCategories = [];
let currentFilter = 'all';
let selectedCategory = null;

// Load forum data
async function loadForumData() {
    try {
        // Load categories
        await loadCategories();
        
        // Load posts
        await loadPosts();
        
        // Populate category dropdown
        populateCategoryDropdown();
        
    } catch (error) {
        console.error('Error loading forum data:', error);
        showNotification('Veri yüklenirken bir hata oluştu.', 'error');
    }
}

// Load categories
async function loadCategories() {
    try {
        const response = await fetch('tables/categories?limit=100');
        const data = await response.json();
        
        if (data.data) {
            allCategories = data.data;
            displayCategories();
        }
    } catch (error) {
        console.error('Error loading categories:', error);
        throw error;
    }
}

// Display categories
function displayCategories() {
    const container = document.getElementById('categoriesContainer');
    if (!container) return;
    
    container.innerHTML = '';
    
    allCategories.forEach(category => {
        const card = document.createElement('div');
        card.className = 'category-card';
        card.innerHTML = `
            <i class="fas ${category.icon} category-icon"></i>
            <h3 class="category-name">${category.name}</h3>
            <p class="category-description">${category.description}</p>
            <p class="category-count">
                <i class="fas fa-comments"></i> ${category.post_count || 0} Konu
            </p>
        `;
        
        card.addEventListener('click', () => {
            filterByCategory(category.name);
            switchPage('forum');
        });
        
        container.appendChild(card);
    });
}

// Populate category dropdown
function populateCategoryDropdown() {
    const select = document.getElementById('postCategory');
    if (!select) return;
    
    select.innerHTML = '<option value="">Kategori Seçin</option>';
    
    allCategories.forEach(category => {
        const option = document.createElement('option');
        option.value = category.name;
        option.textContent = category.name;
        select.appendChild(option);
    });
}

// Load posts
async function loadPosts(filter = 'all') {
    try {
        const response = await fetch('tables/posts?limit=100&sort=-created_at');
        const data = await response.json();
        
        if (data.data) {
            allPosts = data.data;
            
            // Sort posts based on filter
            if (filter === 'recent') {
                allPosts.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
            } else if (filter === 'popular') {
                allPosts.sort((a, b) => (b.likes || 0) - (a.likes || 0));
            }
            
            displayPosts();
        }
    } catch (error) {
        console.error('Error loading posts:', error);
        throw error;
    }
}

// Display posts
async function displayPosts() {
    const container = document.getElementById('postsContainer');
    if (!container) return;
    
    container.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i> Yükleniyor...</div>';
    
    try {
        // Filter posts
        let filteredPosts = allPosts.filter(post => !post.reply_to); // Only show main posts, not replies
        
        if (selectedCategory) {
            filteredPosts = filteredPosts.filter(post => post.category === selectedCategory);
        }
        
        if (filteredPosts.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-comments"></i>
                    <h3>Henüz gönderi yok</h3>
                    <p>İlk gönderiyi siz oluşturun!</p>
                </div>
            `;
            return;
        }
        
        // Load all users to get anonymous names
        const usersResponse = await fetch('tables/users?limit=1000');
        const usersData = await usersResponse.json();
        const users = usersData.data || [];
        
        // Create user map for quick lookup
        const userMap = {};
        users.forEach(user => {
            userMap[user.id] = user;
        });
        
        container.innerHTML = '';
        
        for (const post of filteredPosts) {
            const author = userMap[post.user_id];
            const authorName = author ? author.anonymous_name : 'Anonim Kullanıcı';
            const avatarColor = author ? author.avatar_color : '#6366f1';
            const authorInitial = authorName.charAt(0);
            
            // Count replies
            const replyCount = allPosts.filter(p => p.reply_to === post.id).length;
            
            const postCard = document.createElement('div');
            postCard.className = 'post-card';
            postCard.innerHTML = `
                <div class="post-header">
                    <div class="post-author">
                        <div class="post-avatar" style="background-color: ${avatarColor}">
                            ${authorInitial}
                        </div>
                        <div class="post-author-info">
                            <div class="post-author-name">${authorName}</div>
                            <div class="post-time">${formatDate(post.created_at)}</div>
                        </div>
                    </div>
                    <div class="post-category">${post.category}</div>
                </div>
                <h3 class="post-title">${escapeHtml(post.title)}</h3>
                <div class="post-content">${truncateText(escapeHtml(post.content), 200)}</div>
                <div class="post-footer">
                    <div class="post-action">
                        <i class="fas fa-heart"></i>
                        <span>${post.likes || 0}</span>
                    </div>
                    <div class="post-action">
                        <i class="fas fa-comment"></i>
                        <span>${replyCount}</span>
                    </div>
                    <div class="post-action">
                        <i class="fas fa-eye"></i>
                        <span>Detay</span>
                    </div>
                </div>
            `;
            
            postCard.addEventListener('click', () => openPostDetail(post.id));
            
            container.appendChild(postCard);
        }
        
    } catch (error) {
        console.error('Error displaying posts:', error);
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-exclamation-triangle"></i>
                <h3>Bir hata oluştu</h3>
                <p>Gönderiler yüklenemedi.</p>
            </div>
        `;
    }
}

// Open post detail in modal
async function openPostDetail(postId) {
    const modal = document.getElementById('postModal');
    const postDetail = document.getElementById('postDetail');
    
    if (!modal || !postDetail) return;
    
    modal.classList.add('active');
    postDetail.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i> Yükleniyor...</div>';
    
    try {
        // Get post
        const post = allPosts.find(p => p.id === postId);
        if (!post) {
            throw new Error('Post not found');
        }
        
        // Get author
        const usersResponse = await fetch('tables/users?limit=1000');
        const usersData = await usersResponse.json();
        const users = usersData.data || [];
        
        const userMap = {};
        users.forEach(user => {
            userMap[user.id] = user;
        });
        
        const author = userMap[post.user_id];
        const authorName = author ? author.anonymous_name : 'Anonim Kullanıcı';
        const avatarColor = author ? author.avatar_color : '#6366f1';
        const authorInitial = authorName.charAt(0);
        
        // Get replies
        const replies = allPosts.filter(p => p.reply_to === postId);
        
        let repliesHtml = '';
        replies.forEach(reply => {
            const replyAuthor = userMap[reply.user_id];
            const replyAuthorName = replyAuthor ? replyAuthor.anonymous_name : 'Anonim Kullanıcı';
            const replyAvatarColor = replyAuthor ? replyAuthor.avatar_color : '#6366f1';
            const replyInitial = replyAuthorName.charAt(0);
            
            repliesHtml += `
                <div class="reply-card" style="background: var(--bg-tertiary); padding: 1rem; border-radius: 0.5rem; margin-bottom: 1rem;">
                    <div class="post-author" style="margin-bottom: 0.5rem;">
                        <div class="post-avatar" style="background-color: ${replyAvatarColor}">
                            ${replyInitial}
                        </div>
                        <div class="post-author-info">
                            <div class="post-author-name">${replyAuthorName}</div>
                            <div class="post-time">${formatDate(reply.created_at)}</div>
                        </div>
                    </div>
                    <div style="color: var(--text-secondary); line-height: 1.6;">
                        ${escapeHtml(reply.content)}
                    </div>
                </div>
            `;
        });
        
        postDetail.innerHTML = `
            <div class="post-header" style="margin-bottom: 1rem;">
                <div class="post-author">
                    <div class="post-avatar" style="background-color: ${avatarColor}">
                        ${authorInitial}
                    </div>
                    <div class="post-author-info">
                        <div class="post-author-name">${authorName}</div>
                        <div class="post-time">${formatDate(post.created_at)}</div>
                    </div>
                </div>
                <div class="post-category">${post.category}</div>
            </div>
            <h2 style="margin-bottom: 1rem; color: var(--text-primary);">${escapeHtml(post.title)}</h2>
            <div style="color: var(--text-secondary); line-height: 1.8; margin-bottom: 2rem; white-space: pre-wrap;">
                ${escapeHtml(post.content)}
            </div>
            <div class="post-footer" style="margin-bottom: 2rem;">
                <button class="btn btn-primary" onclick="likePost('${post.id}')">
                    <i class="fas fa-heart"></i> Beğen (${post.likes || 0})
                </button>
            </div>
            <hr style="border: none; border-top: 1px solid var(--border-color); margin: 2rem 0;">
            <h3 style="margin-bottom: 1rem; color: var(--text-primary);">
                <i class="fas fa-comments"></i> Yanıtlar (${replies.length})
            </h3>
            ${currentUser ? `
                <form id="replyForm" style="margin-bottom: 2rem;">
                    <textarea 
                        id="replyContent" 
                        placeholder="Yanıtınızı yazın..." 
                        required 
                        rows="3"
                        style="width: 100%; background: var(--bg-tertiary); border: 1px solid var(--border-color); color: var(--text-primary); padding: 1rem; border-radius: 0.5rem; font-family: inherit; resize: vertical;"
                    ></textarea>
                    <button type="submit" class="btn btn-primary" style="margin-top: 1rem;">
                        <i class="fas fa-paper-plane"></i> Yanıtla
                    </button>
                </form>
            ` : '<p style="color: var(--text-muted); text-align: center; padding: 1rem; background: var(--bg-tertiary); border-radius: 0.5rem; margin-bottom: 2rem;">Yanıt yazmak için giriş yapın</p>'}
            <div id="repliesContainer">
                ${repliesHtml || '<p style="color: var(--text-muted); text-align: center;">Henüz yanıt yok</p>'}
            </div>
        `;
        
        // Setup reply form
        if (currentUser) {
            const replyForm = document.getElementById('replyForm');
            if (replyForm) {
                replyForm.addEventListener('submit', async (e) => {
                    e.preventDefault();
                    await submitReply(postId);
                });
            }
        }
        
    } catch (error) {
        console.error('Error loading post detail:', error);
        postDetail.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-exclamation-triangle"></i>
                <h3>Bir hata oluştu</h3>
                <p>Gönderi yüklenemedi.</p>
            </div>
        `;
    }
}

// Close modal
document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('postModal');
    const closeBtn = document.querySelector('.modal-close');
    
    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            modal.classList.remove('active');
        });
    }
    
    if (modal) {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.classList.remove('active');
            }
        });
    }
});

// Like post
async function likePost(postId) {
    if (!currentUser) {
        showNotification('Beğenmek için giriş yapın', 'warning');
        return;
    }
    
    try {
        const post = allPosts.find(p => p.id === postId);
        if (!post) return;
        
        const newLikes = (post.likes || 0) + 1;
        
        const response = await fetch(`tables/posts/${postId}`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ likes: newLikes })
        });
        
        if (response.ok) {
            post.likes = newLikes;
            showNotification('Beğenildi!', 'success');
            
            // Refresh the post detail
            openPostDetail(postId);
        }
    } catch (error) {
        console.error('Error liking post:', error);
        showNotification('Bir hata oluştu', 'error');
    }
}

// Submit reply
async function submitReply(postId) {
    const replyContent = document.getElementById('replyContent');
    if (!replyContent) return;
    
    const content = replyContent.value.trim();
    if (!content) {
        showNotification('Yanıt boş olamaz', 'warning');
        return;
    }
    
    try {
        const replyData = {
            user_id: currentUser.id,
            category: allPosts.find(p => p.id === postId).category,
            title: '',
            content: content,
            reply_to: postId,
            likes: 0,
            created_at: new Date().toISOString()
        };
        
        const response = await fetch('tables/posts', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(replyData)
        });
        
        if (response.ok) {
            const newReply = await response.json();
            allPosts.push(newReply);
            
            showNotification('Yanıt gönderildi!', 'success');
            replyContent.value = '';
            
            // Refresh the post detail
            openPostDetail(postId);
        }
    } catch (error) {
        console.error('Error submitting reply:', error);
        showNotification('Yanıt gönderilemedi', 'error');
    }
}

// Submit new post
document.addEventListener('DOMContentLoaded', () => {
    const createPostForm = document.getElementById('createPostForm');
    
    if (createPostForm) {
        createPostForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            if (!currentUser) {
                showNotification('Gönderi oluşturmak için giriş yapın', 'warning');
                return;
            }
            
            const category = document.getElementById('postCategory').value;
            const title = document.getElementById('postTitle').value.trim();
            const content = document.getElementById('postContent').value.trim();
            
            if (!category || !title || !content) {
                showNotification('Tüm alanları doldurun', 'warning');
                return;
            }
            
            try {
                const postData = {
                    user_id: currentUser.id,
                    category: category,
                    title: title,
                    content: content,
                    reply_to: '',
                    likes: 0,
                    created_at: new Date().toISOString()
                };
                
                const response = await fetch('tables/posts', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(postData)
                });
                
                if (response.ok) {
                    const newPost = await response.json();
                    allPosts.unshift(newPost);
                    
                    // Update category count
                    const cat = allCategories.find(c => c.name === category);
                    if (cat) {
                        cat.post_count = (cat.post_count || 0) + 1;
                        await fetch(`tables/categories/${cat.id}`, {
                            method: 'PATCH',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({ post_count: cat.post_count })
                        });
                    }
                    
                    showNotification('Gönderi oluşturuldu!', 'success');
                    createPostForm.reset();
                    displayPosts();
                }
            } catch (error) {
                console.error('Error creating post:', error);
                showNotification('Gönderi oluşturulamadı', 'error');
            }
        });
    }
});

// Filter posts
function filterByCategory(categoryName) {
    selectedCategory = categoryName === 'all' ? null : categoryName;
    displayPosts();
}

// Setup filter buttons
document.addEventListener('DOMContentLoaded', () => {
    const filterButtons = document.querySelectorAll('.filter-btn');
    
    filterButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            filterButtons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            const filter = btn.getAttribute('data-filter');
            currentFilter = filter;
            loadPosts(filter);
        });
    });
});

// Utility functions
function formatDate(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now - date;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    
    if (minutes < 1) return 'Az önce';
    if (minutes < 60) return `${minutes} dakika önce`;
    if (hours < 24) return `${hours} saat önce`;
    if (days < 7) return `${days} gün önce`;
    
    return date.toLocaleDateString('tr-TR');
}

function truncateText(text, maxLength) {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
